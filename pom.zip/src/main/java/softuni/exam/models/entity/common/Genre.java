package softuni.exam.models.entity.common;

public enum Genre {
    CLASSIC_LITERATURE, SCIENCE_FICTION, FANTASY
}
